import streamlit as st
from faq_bot import FAQChatbot

st.set_page_config(page_title="College FAQ Chatbot", page_icon="🎓", layout="centered")

@st.cache_resource
def load_bot():
    return FAQChatbot()

st.title("🎓 College / University FAQ Chatbot")
st.caption("Ask questions about admissions, fees, attendance, examinations, library, hostel, and campus support.")

st.info(
    "This is a demonstration FAQ knowledge base. Its answers are sample guidance, "
    "not official university policy. Verify dates, fees, eligibility, and rules with your institution."
)

try:
    bot = load_bot()
except Exception as exc:
    st.error(f"Could not load the FAQ dataset: {exc}")
    st.stop()

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! 👋 I'm your College FAQ Assistant. What would you like to know?"}
    ]

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

prompt = st.chat_input("Type your question here...")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    result = bot.get_response(prompt)
    answer = result["answer"]
    with st.chat_message("assistant"):
        st.markdown(answer)
        if result["matched"]:
            with st.expander("How this answer was selected"):
                st.write("Matched FAQ:", result["matched_question"])
                st.write(f"Cosine similarity: {result['score']:.3f}")
    st.session_state.messages.append({"role": "assistant", "content": answer})

with st.sidebar:
    st.header("About this project")
    st.write("NLP preprocessing: NLTK")
    st.write("Question matching: TF-IDF + cosine similarity")
    st.write(f"FAQs in dataset: {len(bot.faqs)}")
    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.rerun()
    st.markdown("---")
    st.caption("For a real deployment, replace the sample CSV with verified university FAQs.")
