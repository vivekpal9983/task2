"""
FAQ matching engine using NLTK, TF-IDF, and cosine similarity.
"""
from pathlib import Path
import pandas as pd
import nltk
from nltk.tokenize import RegexpTokenizer
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_DATASET = BASE_DIR / "data" / "college_faqs.csv"

# RegexpTokenizer performs tokenization without downloading external corpora.
_tokenizer = RegexpTokenizer(r"[A-Za-z0-9']+")
_stemmer = PorterStemmer()
_STOP_WORDS = {
    "a", "an", "the", "is", "are", "am", "was", "were", "be", "been",
    "being", "to", "of", "in", "on", "at", "for", "from", "with", "by",
    "and", "or", "but", "do", "does", "did", "how", "what", "when",
    "where", "who", "why", "which", "can", "could", "would", "should",
    "i", "we", "you", "my", "our", "your", "me", "it", "this", "that"
}

def preprocess_text(text: str) -> list[str]:
    """Lowercase, tokenize, remove common stop words, and stem tokens."""
    tokens = _tokenizer.tokenize(str(text).lower())
    cleaned = [
        _stemmer.stem(token)
        for token in tokens
        if token not in _STOP_WORDS and len(token) > 1
    ]
    return cleaned

class FAQChatbot:
    """Finds the closest FAQ question and returns its answer."""

    def __init__(self, csv_path=DEFAULT_DATASET, threshold=0.16):
        self.csv_path = Path(csv_path)
        self.threshold = threshold
        self.faqs = pd.read_csv(self.csv_path).dropna(subset=["question", "answer"])
        if self.faqs.empty:
            raise ValueError("The FAQ dataset is empty.")
        self.questions = self.faqs["question"].astype(str).tolist()
        self.vectorizer = TfidfVectorizer(
            tokenizer=preprocess_text,
            token_pattern=None,
            lowercase=False,
            ngram_range=(1, 2)
        )
        self.question_vectors = self.vectorizer.fit_transform(self.questions)

    def get_response(self, user_question: str) -> dict:
        """Return answer, matched FAQ, and similarity score."""
        if not user_question or not user_question.strip():
            return {
                "answer": "Please type a question so I can help.",
                "matched_question": None,
                "score": 0.0,
                "matched": False
            }

        query_vector = self.vectorizer.transform([user_question])
        scores = cosine_similarity(query_vector, self.question_vectors).flatten()
        best_index = int(scores.argmax())
        best_score = float(scores[best_index])

        if best_score < self.threshold:
            return {
                "answer": (
                    "Sorry, I couldn't find a close match in my FAQ knowledge base. "
                    "Please rephrase your question or contact your university's "
                    "official office for verified information."
                ),
                "matched_question": None,
                "score": best_score,
                "matched": False
            }

        return {
            "answer": str(self.faqs.iloc[best_index]["answer"]),
            "matched_question": self.questions[best_index],
            "score": best_score,
            "matched": True
        }

if __name__ == "__main__":
    bot = FAQChatbot()
    print("College FAQ Chatbot (type 'exit' to quit)")
    while True:
        question = input("You: ").strip()
        if question.lower() in {"exit", "quit"}:
            print("Bot: Goodbye!")
            break
        result = bot.get_response(question)
        print(f"Bot: {result['answer']}")
        if result["matched"]:
            print(f"(Matched: {result['matched_question']} | Similarity: {result['score']:.2f})")
