import unittest
from faq_bot import FAQChatbot

class TestFAQChatbot(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bot = FAQChatbot()

    def test_admission_question_matches(self):
        result = self.bot.get_response("How do I apply for admission?")
        self.assertTrue(result["matched"])
        self.assertIn("admission", result["answer"].lower())

    def test_empty_question(self):
        result = self.bot.get_response("   ")
        self.assertFalse(result["matched"])
        self.assertIn("type a question", result["answer"].lower())

if __name__ == "__main__":
    unittest.main()
