# AI-Powered College / University FAQ Chatbot

A beginner-friendly FAQ chatbot built with **Python, NLTK, TF-IDF, cosine similarity, Pandas, and Streamlit**. It matches a student's question with the most similar question in a CSV FAQ dataset and returns the corresponding answer.

## Features

- College-focused FAQ dataset with 40 sample question-answer pairs
- Text preprocessing using NLTK: lowercasing, tokenization, stop-word removal, and stemming
- TF-IDF vectorization with unigrams and bigrams
- Cosine similarity to identify the closest FAQ
- Similarity threshold and fallback response for questions without a close match
- Streamlit chat interface with conversation history
- Shows the matched FAQ and similarity score for transparency

## Project structure

```text
college_faq_chatbot/
├── app.py
├── faq_bot.py
├── requirements.txt
├── README.md
└── data/
    └── college_faqs.csv
```

## Requirements

- Python 3.9 or newer
- pip

## Run locally

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Create and activate a virtual environment (recommended):

   **Windows**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

   **macOS / Linux**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the chatbot:

   ```bash
   streamlit run app.py
   ```

6. Streamlit will show a local URL (usually `http://localhost:8501`). Open it in your browser.

## How it works

1. **Collect FAQs:** `data/college_faqs.csv` stores questions and answers.
2. **Preprocess:** `preprocess_text()` in `faq_bot.py` lowercases, tokenizes, removes common stop words, and stems words using NLTK.
3. **Vectorize:** `TfidfVectorizer` converts FAQ questions into numerical TF-IDF vectors.
4. **Match:** `cosine_similarity` compares a user's question with all stored FAQ questions.
5. **Respond:** The chatbot returns the answer for the highest-scoring FAQ if the score meets the configured threshold. Otherwise, it returns a fallback message.
6. **Interact:** `app.py` provides the Streamlit chat interface.

## Customize the FAQ dataset

Edit `data/college_faqs.csv`. Keep the two column names exactly as:

- `question`
- `answer`

Add institution-verified information before using the chatbot for real students. The included answers are generic sample guidance and must not be treated as official policies, fees, dates, or eligibility rules.

## Test questions

Try these in the chat interface:

- How can I apply for admission?
- Where can I find the fee structure?
- How do I check my exam results?
- What is the attendance requirement?
- How can I apply for hostel accommodation?

Also try an unrelated question to see the fallback response.

## Limitations and future improvements

- This is a retrieval-based FAQ chatbot, not a generative AI model.
- It can only answer questions represented by the FAQ dataset.
- Similarity matching may select an imperfect match; tune the threshold and expand the dataset.
- Future work could include more verified FAQs, multilingual support, intent classification, spelling correction, and deployment.

## Task 2 requirement mapping

| Task 2 requirement | Implementation |
|---|---|
| Collect FAQs | `data/college_faqs.csv` |
| Preprocess text with NLP | NLTK tokenizer, stop-word removal, Porter stemming |
| Match with cosine similarity | `TfidfVectorizer` + `cosine_similarity` |
| Display best matching answer | `FAQChatbot.get_response()` |
| Optional chat UI | Streamlit interface in `app.py` |

## Author

Add your name, course, institution, and internship details here before submission.
